from django.shortcuts import render
import joblib
import numpy as np
import os

model_path = os.path.join(os.path.dirname(__file__), 'model.joblib')
model = joblib.load(model_path)

def predict_price(request):
    if request.method == 'POST':
        present_price = float(request.POST['present_price'])
        kms_driven = int(request.POST['kms_driven'])
        owner = int(request.POST['owner'])
        year = int(request.POST['year'])
        fuel_type = int(request.POST['fuel_type'])
        seller_type = int(request.POST['seller_type'])
        transmission = int(request.POST['transmission'])

        input_data = np.array([[present_price, kms_driven, owner, year, fuel_type, seller_type, transmission]])
        prediction = model.predict(input_data)[0]

        return render(request, 'predict.html', {'prediction': round(prediction, 2)})

    return render(request, 'predict.html')
